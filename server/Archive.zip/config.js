function getUrl (field) {
	return "https://alexa-tv-control.firebaseio.com/"+field+".json";

}

var appId = 'amzn1.ask.skill.b70455c2-0b54-4dd9-a6d1-362e9bb70c77'

module.exports.getUrl = getUrl;
module.exports.appId = appId;